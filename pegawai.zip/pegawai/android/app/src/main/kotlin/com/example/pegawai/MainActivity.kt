package com.example.pegawai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
